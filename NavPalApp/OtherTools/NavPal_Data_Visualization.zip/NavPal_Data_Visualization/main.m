function main()

    nsh_floor1_original = 'nsh_1_f_room.txt';
    nsh_floor2_original = 'nsh_2_f_room.txt';

    % Note the absolute paths. If you use this script on your own machine,
    % you will need to change the paths of the "_room.txt" files.
    nsh_floor1 = 'C:\Users\rCommerce\Documents\Projects\PythonCode\ParsingXMLFile\nsh_1_f_vec_room_python_output.txt';
    nsh_floor2 = 'C:\Users\rCommerce\Documents\Projects\PythonCode\ParsingXMLFile\nsh_2_f_vec_room_python_output.txt';
    
    nsh_floor3_newSVG = 'C:\Users\rCommerce\Documents\Projects\PythonCode\ParsingXMLFile\2011_Newell-Simon_GIS-1_v47_3_room_python_output.txt';

    floor = nsh_floor1_original;
    
    f_VisualizeRooms(2, floor);

end

